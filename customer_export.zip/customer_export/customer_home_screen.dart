import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_design_system.dart';
import '../../../../shared/widgets/app_card.dart';
import '../../../../core/widgets/empty_state_widget.dart';

/// Customer Home: hero section, premium cards, clear hierarchy.
class CustomerHomeScreen extends ConsumerWidget {
  const CustomerHomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      backgroundColor: AppDesignSystem.backgroundOffWhite,
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(
          horizontal: AppDesignSystem.screenHorizontalPadding,
          vertical: AppDesignSystem.space24,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Discover home cooks',
              style: Theme.of(context).textTheme.displaySmall?.copyWith(
                    fontWeight: FontWeight.w700,
                    color: AppDesignSystem.textPrimary,
                  ),
            ),
            const SizedBox(height: AppDesignSystem.space8),
            Text(
              'Order fresh meals from your community.',
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: AppDesignSystem.textSecondary,
                    height: 1.45,
                  ),
            ),
            const SizedBox(height: AppDesignSystem.space32),
            AppCard(
              onTap: () {},
              child: Row(
                children: [
                  Container(
                    width: 56,
                    height: 56,
                    decoration: BoxDecoration(
                      color: AppDesignSystem.primaryGreen.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(AppDesignSystem.radiusMedium),
                    ),
                    child: Icon(
                      Icons.restaurant_rounded,
                      size: 28,
                      color: AppDesignSystem.primaryGreen,
                    ),
                  ),
                  const SizedBox(width: AppDesignSystem.space16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Near you',
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                fontWeight: FontWeight.w600,
                              ),
                        ),
                        const SizedBox(height: AppDesignSystem.space4),
                        Text(
                          'Chefs in your area',
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ],
                    ),
                  ),
                  const Icon(Icons.chevron_right_rounded, color: AppDesignSystem.textSecondary),
                ],
              ),
            ),
            const SizedBox(height: AppDesignSystem.space48),
            const EmptyStateWidget(
              icon: Icons.explore_rounded,
              title: 'Explore chefs',
              subtitle: 'Browse by cuisine or location from the Explore tab.',
            ),
            const SizedBox(height: AppDesignSystem.space32),
          ],
        ),
      ),
    );
  }
}
