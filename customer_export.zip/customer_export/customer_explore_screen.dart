import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_design_system.dart';
import '../../../../core/widgets/empty_state_widget.dart';

/// Customer tab: Explore – browse chefs and cuisines.
class CustomerExploreScreen extends ConsumerWidget {
  const CustomerExploreScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      backgroundColor: AppDesignSystem.backgroundOffWhite,
      appBar: AppBar(
        title: const Text('Explore'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: AppDesignSystem.screenHorizontalPadding, vertical: AppDesignSystem.space24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Find home cooks',
              style: Theme.of(context).textTheme.headlineMedium,
            ),
            const SizedBox(height: 8),
            Text(
              'Browse by cuisine or see who\'s cooking today.',
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: AppDesignSystem.textSecondary,
                  ),
            ),
            const SizedBox(height: 32),
            const EmptyStateWidget(
              icon: Icons.storefront_rounded,
              title: 'Coming soon',
              subtitle: 'Chef listings and filters will appear here.',
            ),
          ],
        ),
      ),
    );
  }
}
