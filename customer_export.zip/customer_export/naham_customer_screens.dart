// ============================================================
// NAHAM CUSTOMER APP — Purple theme, main nav, home, reels, orders, chat, profile
// ============================================================

import 'package:flutter/material.dart';

// ==================== COLORS & THEME ====================
class NahamCustomerColors {
  static const Color primary = Color(0xFF9B7FD4);
  static const Color primaryDark = Color(0xFF7C5CBF);
  static const Color primaryLight = Color(0xFFC4B0E8);
  static const Color background = Color(0xFFF5F0FF);
  static const Color cardBg = Color(0xFFFFFFFF);
  static const Color textDark = Color(0xFF1A1A1A);
  static const Color textGrey = Color(0xFF888888);
  static const Color star = Color(0xFFFFC107);
  static const Color categoryBg = Color(0xFFEDE9FE);
  static const Color bottomNavBg = Color(0xFFC4B0E8);
  static const Color bannerPink = Color(0xFFEC4899);
  static const Color cardGradientStart = Color(0xFFEDE9FE);
  static const Color cardGradientEnd = Color(0xFFF5F3FF);
  static const Color ratingBg = Color(0xFFFFF7ED);
}

/// Shared header for all customer screens: purple #9B7FD4, fork+spoon + "Naham" white.
Widget nahamCustomerHeader({
  String? title,
  List<Widget>? actions,
}) {
  return Container(
    color: NahamCustomerColors.primary,
    padding: EdgeInsets.only(
      top: 12,
      bottom: 12,
      left: 16,
      right: 16,
    ),
    child: SafeArea(
      bottom: false,
      child: Row(
        children: [
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(
                  Icons.restaurant,
                  color: Colors.white,
                  size: 22,
                ),
              ),
              const SizedBox(width: 8),
              const Text(
                'Naham',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          if (title != null) ...[
            Expanded(
              child: Text(
                title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ] else
            const Spacer(),
          if (actions != null && actions!.isNotEmpty)
            Row(mainAxisSize: MainAxisSize.min, children: actions!)
          else
            const SizedBox(width: 48),
        ],
      ),
    ),
  );
}

// ==================== MAIN NAVIGATION ====================
class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _currentIndex = 0; // Home, Reels, Orders, Chat, Profile
  int _cartCount = 0;

  void _addToCart() {
    setState(() {
      _cartCount++;
    });
  }

  @override
  Widget build(BuildContext context) {
    final screens = [
      NahamCustomerHomeScreen(
          onAddToCart: _addToCart, cartCount: _cartCount),
      const NahamCustomerReelsScreen(),
      const NahamCustomerOrdersScreen(),
      const NahamCustomerChatScreen(),
      const NahamCustomerProfileScreen(),
    ];

    return Scaffold(
      body: screens[_currentIndex],
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  // Nav bar order: Reels, Orders, Home (center elevated), Chat, Profile
  static const List<int> _navToScreenIndex = [1, 2, 0, 3, 4];

  Widget _buildBottomNav() {
    const labels = ['Reels', 'Orders', 'Home', 'Chat', 'Profile'];
    const icons = [
      (Icons.play_circle_outline_rounded, Icons.play_circle_rounded),
      (Icons.shopping_bag_outlined, Icons.shopping_bag_rounded),
      (Icons.home_outlined, Icons.home_rounded),
      (Icons.chat_bubble_outline_rounded, Icons.chat_bubble_rounded),
      (Icons.person_outline_rounded, Icons.person_rounded),
    ];
    return Container(
      height: 72,
      decoration: BoxDecoration(
        color: NahamCustomerColors.bottomNavBg,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 16,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: List.generate(5, (navIndex) {
            final screenIndex = _navToScreenIndex[navIndex];
            final isActive = _currentIndex == screenIndex;
            final isCenterHome = navIndex == 2;
            final activeColor = NahamCustomerColors.primaryDark;
            return GestureDetector(
              onTap: () => setState(() => _currentIndex = screenIndex),
              behavior: HitTestBehavior.opaque,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (isCenterHome)
                    Container(
                      width: 52,
                      height: 52,
                      decoration: BoxDecoration(
                        color: isActive
                            ? activeColor
                            : Colors.white.withOpacity(0.5),
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.15),
                            blurRadius: 12,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Icon(
                        isActive ? icons[2].$2 : icons[2].$1,
                        size: 26,
                        color: isActive
                            ? Colors.white
                            : NahamCustomerColors.textGrey,
                      ),
                    )
                  else
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: isActive
                            ? activeColor.withOpacity(0.25)
                            : Colors.transparent,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        isActive ? icons[navIndex].$2 : icons[navIndex].$1,
                        size: 24,
                        color: isActive
                            ? activeColor
                            : NahamCustomerColors.textGrey,
                      ),
                    ),
                  const SizedBox(height: 4),
                  Text(
                    labels[navIndex],
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight:
                          isActive ? FontWeight.w700 : FontWeight.w500,
                      color: isActive
                          ? activeColor
                          : NahamCustomerColors.textGrey,
                    ),
                  ),
                ],
              ),
            );
          }),
        ),
      ),
    );
  }
}

// ==================== HOME SCREEN (Flutter) ====================
class NahamCustomerHomeScreen extends StatefulWidget {
  final VoidCallback onAddToCart;
  final int cartCount;

  const NahamCustomerHomeScreen({
    super.key,
    required this.onAddToCart,
    required this.cartCount,
  });

  @override
  State<NahamCustomerHomeScreen> createState() =>
      _NahamCustomerHomeScreenState();
}

class _NahamCustomerHomeScreenState extends State<NahamCustomerHomeScreen> {
  String _activeCategory = 'Northern';

  // Cuisine Regions (Figma)
  static const _categories = [
    'Northern',
    'Eastern',
    'Southern',
    'Najdi',
    'Western',
  ];

  static final _kitchens = [
    {
      'name': "Maria's Kitchen",
      'rating': 4.9,
      'img': '🍝',
      'cuisine': 'إيطالي',
      'distance': '1.2 km',
      'time': '25-35 دقيقة',
      'badge': 'الأكثر طلباً',
    },
    {
      'name': 'Chef Qasim',
      'rating': 4.7,
      'img': '🍛',
      'cuisine': 'عربي',
      'distance': '0.8 km',
      'time': '20-30 دقيقة',
      'badge': null,
    },
    {
      'name': "Sarah's Home",
      'rating': 4.8,
      'img': '🥗',
      'cuisine': 'صحي',
      'distance': '2.1 km',
      'time': '30-40 دقيقة',
      'badge': 'جديد',
    },
    {
      'name': 'Um Khalid',
      'rating': 4.6,
      'img': '🍲',
      'cuisine': 'كويتي',
      'distance': '1.5 km',
      'time': '35-45 دقيقة',
      'badge': null,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NahamCustomerColors.background,
      body: Directionality(
        textDirection: TextDirection.rtl,
      child: Column(
        children: [
          _buildHeader(context),
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                    _buildCategoryChips(),
                    _buildPopularDishes(context),
                    _buildBanner(),
                    _buildFamousCooks(context),
                    const SizedBox(height: 100),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 10,
        left: 20,
        right: 20,
        bottom: 16,
      ),
      decoration: const BoxDecoration(
        color: NahamCustomerColors.primary,
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(20),
          bottomRight: Radius.circular(20),
        ),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Icon(
                      Icons.restaurant,
                      color: Colors.white,
                      size: 22,
                    ),
                  ),
                  const SizedBox(width: 8),
                  const Text(
                    'Naham',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: const Icon(Icons.search_rounded,
                        color: Colors.white, size: 22),
                    onPressed: () {},
                    style: IconButton.styleFrom(
                      backgroundColor: Colors.white.withOpacity(0.2),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      minimumSize: const Size(38, 38),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Stack(
                    clipBehavior: Clip.none,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.shopping_cart_outlined,
                            color: Colors.white, size: 22),
                        onPressed: () {},
                        style: IconButton.styleFrom(
                          backgroundColor: Colors.white.withOpacity(0.2),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          minimumSize: const Size(38, 38),
                        ),
                      ),
                      if (widget.cartCount > 0)
                        Positioned(
                          top: 4,
                          right: 4,
                          child: Container(
                            padding: const EdgeInsets.all(4),
                            constraints: const BoxConstraints(
                                minWidth: 18, minHeight: 18),
                            decoration: const BoxDecoration(
                              color: Color(0xFFEF4444),
                              shape: BoxShape.circle,
                            ),
                            child: Text(
                              '${widget.cartCount > 99 ? "99+" : widget.cartCount}',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              const Text('📍', style: TextStyle(fontSize: 14)),
              const SizedBox(width: 6),
              Text(
                'الرياض، حي الملقا',
                style: TextStyle(
                  fontSize: 13,
                  color: Colors.white.withOpacity(0.9),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(
              children: [
                const Text('🔍', style: TextStyle(fontSize: 18)),
                const SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    decoration: const InputDecoration(
                      hintText: 'ابحث عن وجبة أو مطبخ...',
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.zero,
                      isDense: true,
                    ),
                    style: const TextStyle(fontSize: 14),
                    textAlign: TextAlign.right,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryChips() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
      child: Row(
        children: _categories.map((c) {
          final isActive = _activeCategory == c;
          return Padding(
            padding: const EdgeInsets.only(left: 8),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: () => setState(() => _activeCategory = c),
                borderRadius: BorderRadius.circular(20),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 8,
                  ),
                  decoration: BoxDecoration(
                    color: isActive
                        ? NahamCustomerColors.primary
                        : Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: isActive
                        ? [
                            BoxShadow(
                              color: NahamCustomerColors.primary
                                  .withOpacity(0.35),
                              blurRadius: 12,
                              offset: const Offset(0, 4),
                            ),
                          ]
                        : [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.08),
                              blurRadius: 4,
                              offset: const Offset(0, 1),
                            ),
                          ],
                  ),
                  child: Text(
                    c,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: isActive
                          ? Colors.white
                          : NahamCustomerColors.textGrey,
                    ),
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildPopularDishes(BuildContext context) {
    final dishes = [
      {'name': 'Gereesh', 'price': '20.0 SR'},
      {'name': 'Qrsan', 'price': '22.0 SR'},
      {'name': 'Mandy Laham', 'price': '90.0 SR'},
      {'name': 'Cream', 'price': '35.0 SR'},
    ];
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Popular Dishes',
            style: TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 16,
              color: NahamCustomerColors.textDark,
            ),
          ),
          const SizedBox(height: 12),
          GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 2,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 0.75,
            children: dishes.map((d) => _PopularDishCard(
                  name: d['name']!,
                  price: d['price']!,
                  onAddToCart: widget.onAddToCart,
                )).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildBanner() {
    return Container(
      margin: const EdgeInsets.fromLTRB(20, 12, 20, 0),
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            NahamCustomerColors.primary,
            NahamCustomerColors.bannerPink,
          ],
        ),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'عرض اليوم',
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.white.withOpacity(0.8),
                ),
              ),
              const SizedBox(height: 4),
              const Text(
                'خصم 20%',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                'على أول طلب لك 🎉',
                style: TextStyle(
                  fontSize: 13,
                  color: Colors.white.withOpacity(0.85),
                ),
              ),
            ],
          ),
          const Text('🍽️', style: TextStyle(fontSize: 60)),
        ],
      ),
    );
  }

  Widget _buildFamousCooks(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Famous Cooks',
            style: TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 16,
              color: NahamCustomerColors.textDark,
            ),
          ),
          const SizedBox(height: 12),
          ..._kitchens.map((k) => _KitchenCard(
                name: k['name'] as String,
                rating: k['rating'] as double,
                img: k['img'] as String,
                cuisine: k['cuisine'] as String,
                distance: k['distance'] as String,
                time: k['time'] as String,
                badge: k['badge'] as String?,
                onAddToCart: widget.onAddToCart,
              )),
        ],
      ),
    );
  }
}

class _PopularDishCard extends StatelessWidget {
  final String name;
  final String price;
  final VoidCallback onAddToCart;

  const _PopularDishCard({
    required this.name,
    required this.price,
    required this.onAddToCart,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: NahamCustomerColors.cardBg,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.07),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            flex: 3,
            child: Container(
              width: double.infinity,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    NahamCustomerColors.cardGradientStart,
                    NahamCustomerColors.cardGradientEnd,
                  ],
                ),
                borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
              ),
              child: const Center(
                  child: Icon(Icons.restaurant,
                      size: 36, color: NahamCustomerColors.primary)),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                    color: NahamCustomerColors.textDark,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      price,
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: NahamCustomerColors.primary,
                      ),
                    ),
                    GestureDetector(
                      onTap: onAddToCart,
                      child: Container(
                        width: 28,
                        height: 28,
                        decoration: BoxDecoration(
                          color: NahamCustomerColors.primary,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.add,
                            color: Colors.white, size: 18),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _KitchenCard extends StatelessWidget {
  final String name;
  final double rating;
  final String img;
  final String cuisine;
  final String distance;
  final String time;
  final String? badge;
  final VoidCallback onAddToCart;

  const _KitchenCard({
    required this.name,
    required this.rating,
    required this.img,
    required this.cuisine,
    required this.distance,
    required this.time,
    this.badge,
    required this.onAddToCart,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        color: NahamCustomerColors.cardBg,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.07),
            blurRadius: 12,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              Container(
                height: 120,
                width: double.infinity,
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      NahamCustomerColors.cardGradientStart,
                      NahamCustomerColors.cardGradientEnd,
                    ],
                  ),
                ),
                child: Center(
                  child: Text(img, style: const TextStyle(fontSize: 60)),
                ),
              ),
              if (badge != null)
                Positioned(
                  top: 10,
                  right: 10,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 3,
                    ),
                    decoration: BoxDecoration(
                      color: NahamCustomerColors.primary,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      badge!,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      name,
                      style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 15,
                        color: NahamCustomerColors.textDark,
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: NahamCustomerColors.ratingBg,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Text('⭐', style: TextStyle(fontSize: 12)),
                          const SizedBox(width: 4),
                          Text(
                            rating.toString(),
                            style: const TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              color: NahamCustomerColors.star,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Text(
                      '🍴 $cuisine',
                      style: const TextStyle(
                        fontSize: 13,
                        color: NahamCustomerColors.textGrey,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      '📍 $distance',
                      style: const TextStyle(
                        fontSize: 13,
                        color: NahamCustomerColors.textGrey,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      '⏱ $time',
                      style: const TextStyle(
                        fontSize: 13,
                        color: NahamCustomerColors.textGrey,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: onAddToCart,
                      borderRadius: BorderRadius.circular(12),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              NahamCustomerColors.primary,
                              NahamCustomerColors.primaryLight,
                            ],
                          ),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Center(
                          child: Text(
                            'أضف للسلة +',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ==================== REELS SCREEN ====================
class NahamCustomerReelsScreen extends StatefulWidget {
  const NahamCustomerReelsScreen({super.key});

  @override
  State<NahamCustomerReelsScreen> createState() =>
      _NahamCustomerReelsScreenState();
}

class _NahamCustomerReelsScreenState extends State<NahamCustomerReelsScreen> {
  final PageController _pageController = PageController();
  int _currentPage = 0;

  final List<Map<String, String>> _reels = [
    {'chef': "Maria's Kitchen", 'dish': 'Kabsa', 'likes': '1.2k'},
    {'chef': 'Chef Qasm', 'dish': 'Mandi', 'likes': '890'},
    {'chef': "Om Saleh's Kitchen", 'dish': 'Jareesh', 'likes': '2.3k'},
    {'chef': 'Chef Ahmed', 'dish': 'Saleeg', 'likes': '456'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: PageView.builder(
        controller: _pageController,
        scrollDirection: Axis.vertical,
        itemCount: _reels.length,
        onPageChanged: (index) => setState(() => _currentPage = index),
        itemBuilder: (context, index) {
          return _buildReelItem(_reels[index], context);
        },
      ),
    );
  }

  Widget _buildReelItem(Map<String, String> reel, BuildContext context) {
    return Stack(
      children: [
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                NahamCustomerColors.primary.withOpacity(0.8),
                Colors.black,
              ],
            ),
          ),
          child: const Center(
            child: Icon(Icons.restaurant,
                size: 80, color: Colors.white30),
          ),
        ),
        Positioned(
          top: 0,
          left: 0,
          right: 0,
          child: nahamCustomerHeader(
            actions: [
              IconButton(
                icon: const Icon(Icons.search_rounded, color: Colors.white),
                onPressed: () {},
              ),
            ],
          ),
        ),
        Positioned(
          bottom: 100,
          left: 16,
          right: 70,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: const BoxDecoration(
                      color: NahamCustomerColors.primaryLight,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.person,
                        color: NahamCustomerColors.primaryDark),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    reel['chef']!,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                reel['dish']!,
                style: const TextStyle(
                    color: Colors.white70, fontSize: 14),
              ),
            ],
          ),
        ),
        Positioned(
          bottom: 100,
          right: 16,
          child: Column(
            children: [
              _reelAction(Icons.favorite_border, reel['likes']!),
              const SizedBox(height: 20),
              _reelAction(Icons.comment_outlined, 'Comment'),
              const SizedBox(height: 20),
              _reelAction(Icons.share_outlined, 'Share'),
              const SizedBox(height: 20),
              _reelAction(Icons.add_shopping_cart, 'Order'),
            ],
          ),
        ),
      ],
    );
  }

  Widget _reelAction(IconData icon, String label) {
    return Column(
      children: [
        Icon(icon, color: Colors.white, size: 28),
        const SizedBox(height: 4),
        Text(label,
            style: const TextStyle(color: Colors.white, fontSize: 11)),
      ],
    );
  }
}

// ==================== ORDERS SCREEN ====================
class NahamCustomerOrdersScreen extends StatefulWidget {
  const NahamCustomerOrdersScreen({super.key});

  @override
  State<NahamCustomerOrdersScreen> createState() =>
      _NahamCustomerOrdersScreenState();
}

class _NahamCustomerOrdersScreenState extends State<NahamCustomerOrdersScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NahamCustomerColors.background,
      body: Column(
        children: [
          nahamCustomerHeader(title: 'My Orders'),
          Container(
            color: Colors.white,
            child: TabBar(
              controller: _tabController,
              indicatorColor: NahamCustomerColors.primaryDark,
              labelColor: NahamCustomerColors.primaryDark,
              unselectedLabelColor: NahamCustomerColors.textGrey,
              tabs: const [
                Tab(text: 'Active'),
                Tab(text: 'Completed'),
                Tab(text: 'Cancelled'),
              ],
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildActiveOrders(),
                _buildCompletedOrders(),
                _buildCancelledOrders(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActiveOrders() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _orderCard(
          name: 'greesh',
          chef: "Maria's Kitchen",
          status: 'Out for Delivery',
          statusColor: Colors.green,
          price: '20',
          time: '13:28 GM',
          showTrack: true,
          showCall: true,
        ),
        _orderCard(
          name: 'qishd',
          chef: 'on saleh\'s Kitchen',
          status: 'Preparing',
          statusColor: NahamCustomerColors.primary,
          price: '25',
          time: '14:05 GM',
          showTrack: true,
          showCall: false,
        ),
      ],
    );
  }

  Widget _buildCompletedOrders() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _orderCard(
          name: 'cremah',
          chef: "om saleh's Kitchen",
          status: 'Order Delivered',
          statusColor: Colors.green,
          price: '35',
          time: '12:00 GM',
          showTrack: false,
          showCall: false,
          showRate: true,
        ),
      ],
    );
  }

  Widget _buildCancelledOrders() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _orderCard(
          name: 'qishied',
          chef: "on saleh's Kitchen",
          status: 'Cancelled',
          statusColor: Colors.red,
          price: '22',
          time: '10:30 GM',
          showTrack: false,
          showCall: false,
          showReorder: true,
        ),
      ],
    );
  }

  Widget _orderCard({
    required String name,
    required String chef,
    required String status,
    required Color statusColor,
    required String price,
    required String time,
    required bool showTrack,
    required bool showCall,
    bool showRate = false,
    bool showReorder = false,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: NahamCustomerColors.cardBg,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: statusColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  status,
                  style: TextStyle(
                      color: statusColor,
                      fontSize: 12,
                      fontWeight: FontWeight.bold),
                ),
              ),
              Text(time,
                  style: const TextStyle(
                      color: NahamCustomerColors.textGrey,
                      fontSize: 12)),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: NahamCustomerColors.primaryLight
                      .withOpacity(0.3),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(Icons.restaurant,
                    color: NahamCustomerColors.primary),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(name,
                        style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 15)),
                    Text(chef,
                        style: const TextStyle(
                            color: NahamCustomerColors.textGrey,
                            fontSize: 12)),
                  ],
                ),
              ),
              Text(
                '$price SR',
                style: const TextStyle(
                  color: NahamCustomerColors.primaryDark,
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                ),
              ),
            ],
          ),
          if (showTrack || showCall || showRate || showReorder) ...[
            const SizedBox(height: 12),
            Row(
              children: [
                if (showTrack)
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () {},
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(
                            color: NahamCustomerColors.primary),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                      ),
                      child: const Text('Track Order',
                          style: TextStyle(
                              color: NahamCustomerColors.primary)),
                    ),
                  ),
                if (showTrack && showCall) const SizedBox(width: 8),
                if (showCall)
                  Container(
                    decoration: BoxDecoration(
                      color: NahamCustomerColors.primary,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: IconButton(
                      onPressed: () {},
                      icon: const Icon(Icons.phone,
                          color: Colors.white, size: 20),
                    ),
                  ),
                if (showRate)
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {},
                      style: ElevatedButton.styleFrom(
                        backgroundColor: NahamCustomerColors.primary,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                      ),
                      child: const Text('Rate Now',
                          style: TextStyle(color: Colors.white)),
                    ),
                  ),
                if (showReorder) ...[
                  Text('Needs payment',
                      style: TextStyle(
                          color: Colors.red,
                          fontSize: 12,
                          fontWeight: FontWeight.w600)),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {},
                      style: ElevatedButton.styleFrom(
                        backgroundColor: NahamCustomerColors.primary,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                      ),
                      child: const Text('Reorder',
                          style: TextStyle(color: Colors.white)),
                    ),
                  ),
                ],
              ],
            ),
          ],
        ],
      ),
    );
  }
}

// ==================== CHAT SCREEN ====================
class NahamCustomerChatScreen extends StatelessWidget {
  const NahamCustomerChatScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final chats = [
      {
        'name': "Maria's Kitchen",
        'last': 'Your order is ready!',
        'time': '2:30 PM',
        'unread': '2'
      },
      {
        'name': 'Chef Qasm',
        'last': 'Thank you for your order',
        'time': '1:15 PM',
        'unread': '0'
      },
      {
        'name': "Om Saleh's Kitchen",
        'last': 'We are preparing your food',
        'time': 'Yesterday',
        'unread': '0'
      },
    ];

    return Scaffold(
      backgroundColor: NahamCustomerColors.background,
      body: Column(
        children: [
          nahamCustomerHeader(
            title: 'Chat',
            actions: [
              IconButton(
                icon: const Icon(Icons.search_rounded, color: Colors.white),
                onPressed: () {},
              ),
            ],
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: chats.length,
              itemBuilder: (context, index) {
                final chat = chats[index];
                final hasUnread = chat['unread'] != '0';
                return Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: NahamCustomerColors.cardBg,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.06),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 50,
                        height: 50,
                        decoration: BoxDecoration(
                          color: NahamCustomerColors.primaryLight
                              .withOpacity(0.4),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.person,
                            color: NahamCustomerColors.primaryDark),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              chat['name']!,
                              style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14),
                            ),
                            Text(
                              chat['last']!,
                              style: const TextStyle(
                                  color: NahamCustomerColors.textGrey,
                                  fontSize: 12),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(chat['time']!,
                              style: const TextStyle(
                                  color: NahamCustomerColors.textGrey,
                                  fontSize: 11)),
                          if (hasUnread) ...[
                            const SizedBox(height: 4),
                            Container(
                              padding: const EdgeInsets.all(6),
                              decoration: const BoxDecoration(
                                color: NahamCustomerColors.primary,
                                shape: BoxShape.circle,
                              ),
                              child: Text(
                                chat['unread']!,
                                style: const TextStyle(
                                    color: Colors.white, fontSize: 11),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

// ==================== PROFILE SCREEN ====================
class NahamCustomerProfileScreen extends StatelessWidget {
  const NahamCustomerProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NahamCustomerColors.background,
      body: Column(
        children: [
          nahamCustomerHeader(title: 'My Profile'),
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  _buildProfileHeader(context),
                  const SizedBox(height: 20),
                  _buildProfileOptions(context),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileHeader(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 20,
        bottom: 30,
      ),
      decoration: const BoxDecoration(
        color: NahamCustomerColors.primary,
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(30),
          bottomRight: Radius.circular(30),
        ),
      ),
      child: Column(
        children: [
          Stack(
            children: [
              Container(
                width: 90,
                height: 90,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white, width: 3),
                ),
                child: const Icon(Icons.person,
                    size: 50, color: Colors.white),
              ),
              Positioned(
                bottom: 0,
                right: 0,
                child: Container(
                  width: 28,
                  height: 28,
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.camera_alt,
                      size: 16,
                      color: NahamCustomerColors.primary),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          const Text(
            'Ahmad Ali',
            style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold),
          ),
          const Text(
            'Member since 2024',
            style: TextStyle(color: Colors.white70, fontSize: 13),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _statItem('142', 'Orders'),
              Container(
                  width: 1, height: 30, color: Colors.white30),
              _statItem('583', 'Points'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _statItem(String value, String label) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Column(
        children: [
          Text(value,
              style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 20)),
          Text(label,
              style: const TextStyle(
                  color: Colors.white70, fontSize: 12)),
        ],
      ),
    );
  }

  Widget _buildProfileOptions(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [
          _optionCard(
            icon: Icons.edit_outlined,
            title: 'Edit Profile',
            subtitle: 'Name, phone, location',
            onTap: () {},
          ),
          _optionCard(
            icon: Icons.favorite_border,
            title: 'Favorites',
            subtitle: 'Saved cooks & dishes',
            onTap: () {},
          ),
          _optionCard(
            icon: Icons.headset_mic_outlined,
            title: 'Support',
            subtitle: 'Chat with admins',
            onTap: () {},
          ),
          _optionCard(
            icon: Icons.notifications_outlined,
            title: 'Notifications',
            subtitle: 'Notification settings',
            onTap: () {},
          ),
          _optionCard(
            icon: Icons.location_on_outlined,
            title: 'My Addresses',
            subtitle: 'Saved delivery locations',
            onTap: () {},
          ),
          const SizedBox(height: 8),
          Container(
            width: double.infinity,
            margin: const EdgeInsets.only(bottom: 16),
            child: OutlinedButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.logout, color: Colors.red),
              label: const Text('Logout',
                  style: TextStyle(color: Colors.red)),
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: Colors.red),
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _optionCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: NahamCustomerColors.cardBg,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                color: NahamCustomerColors.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon,
                  color: NahamCustomerColors.primary, size: 24),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 14)),
                  Text(subtitle,
                      style: const TextStyle(
                          color: NahamCustomerColors.textGrey,
                          fontSize: 12)),
                ],
              ),
            ),
            const Icon(Icons.chevron_right,
                color: NahamCustomerColors.textGrey),
          ],
        ),
      ),
    );
  }
}
