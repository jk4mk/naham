========================================
ملفات تطبيق العميل (Customer) — نهم
========================================

هذا المجلد يحتوي كل ملفات الكاستمر. انسخ كل ملف لمكانه في مشروع Flutter:

الواجهة البنفسجية (الرئيسية):
  naham_customer_screens.dart  →  lib/features/customer/

تسجيل الدخول والاختيار:
  customer_auth_screen.dart    →  lib/features/auth/screens/
  role_selection_screen.dart   →  lib/features/auth/screens/

الواجهة القديمة (اختياري):
  customer_main.dart           →  lib/features/customer/

شاشات إضافية (اختياري):
  customer_home_screen.dart     →  lib/features/customer/presentation/screens/
  customer_explore_screen.dart  →  lib/features/customer/presentation/screens/
  customer_cart_screen.dart    →  lib/features/customer/presentation/screens/
  customer_profile_screen.dart →  lib/features/customer/presentation/screens/

بعد النسخ، تأكد أن main.dart أو المسار يفتح SplashScreen ثم RoleSelection
وأن اختيار "I'm a Customer" يفتح CustomerAuthScreen، وبعد Login/Register
ينتقل إلى MainNavigationScreen (من naham_customer_screens.dart).

========================================
